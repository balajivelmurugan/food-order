import { Menu } from "src/app/features/menu/types/menu";

export class MenuState {

  menuItems: Menu[] = [];
  cartItems: Menu[] = [];
}
