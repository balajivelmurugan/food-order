export interface Menu {
  name: string,
  type: string,
  cuisine: string,
  availability: Array<string>,
  price: string,
  img_url: string,
  quantity: number
}
