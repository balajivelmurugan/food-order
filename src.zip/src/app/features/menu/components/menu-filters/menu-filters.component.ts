import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-menu-filters',
  templateUrl: './menu-filters.component.html',
  styleUrls: ['./menu-filters.component.scss']
})
export class MenuFiltersComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
