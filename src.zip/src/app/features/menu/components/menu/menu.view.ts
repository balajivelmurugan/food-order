import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-menu',
  templateUrl: './menu.view.html',
  styleUrls: ['./menu.view.scss']
})
export class MenuView implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
