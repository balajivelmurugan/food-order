export interface Order {
  item_name: string,
  type: string,
  cuisine: string,
  price: string,
  order_date: string,
  order_time: string
}
